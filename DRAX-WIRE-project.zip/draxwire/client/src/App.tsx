import { Route, Switch } from 'wouter';
import Home from './pages/Home';
import Admin from './pages/Admin';
import Dealer from './pages/Dealer';
import './index.css';
export default function App(){return <Switch><Route path="/" component={Home}/><Route path="/dashboard" component={Admin}/><Route path="/dealer" component={Dealer}/><Route><Home/></Route></Switch>}
